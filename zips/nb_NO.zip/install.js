var err = initInstall("Norsk bokmål ordliste", "nb-NO@dictionaries.addons.mozilla.org", "2.0.10.2");
if (err != SUCCESS)
    cancelInstall();

var fProgram = getFolder("Program");
err = addDirectory("", "nb-NO@dictionaries.addons.mozilla.org",
		   "dictionaries", fProgram, "dictionaries", true);
if (err != SUCCESS)
    cancelInstall();

performInstall();
