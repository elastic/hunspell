var name = "be-classic@dictionaries.addons.mozilla.org";
var err = initInstall("Belarusian Classic Dictionary", name, "0.1.2");
if (err != SUCCESS)
    cancelInstall();

var fProgram = getFolder("Program");
err = addDirectory("", name, "dictionaries", fProgram, "dictionaries", true);
if (err != SUCCESS)
    cancelInstall();

performInstall();