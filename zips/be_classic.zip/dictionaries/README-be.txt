UTF-8

Беларускі слоўнік для праверкі правапісу.
=============================================
Спадар Алекс Булойчык перарабіў (сканвертаваў) слоўнік 
для праверкі правапісу для працы ў OpenOffice.org,
Mozilla Firefox, Mozilla Thunderbird.
http://alex73.zaval.org/snapshots/spell/
=============================================
Original Word List By:
  Vital Khilko <vk at mova dot org>
  TBM
Copyright Terms: GPL (see the file Copyright for the exact terms)
Wordlist URL: http://mova.linux.by/aspell/
Source Verson: 0.01
=============================================
