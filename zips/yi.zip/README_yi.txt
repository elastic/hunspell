
1. Version

This is version 1.1 of hunspell-yi.

This is a simple conversion by Caolán McNamara <caolanm@redhat.com>
<caolan@skynet.ie> of a raw wordlist kindly provided by Raphael A. Finkel
See: http://www.cs.uky.edu/cgi-bin/cgiwrap/~raphael/dictionary.cgi

2. Copyright

Yiddish spell checker
Copyright 2010 Raphael A. Finkel

3. Licenses

See LICENSES-en.txt
