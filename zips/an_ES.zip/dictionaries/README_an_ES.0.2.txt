(an)
Diccionario ortografico aragon�s.
Versi�n 0.2. (beta)
Copyright (c) 2011 Santiago Paricio (sparicio<at>gmail<dot>com)
Copyright (c) 2011 Juan Pablo Mart�nez (jpmart<at>unizar<dot>es)

   Licencias (Trilicencia MPL1.1/GPLv3+/LGPLv3+):
   * MPL : Mozilla Public License
     version 1.1  --  http://www.mozilla.org/MPL/MPL-1.1.html
   * GPL : GNU General Public License
     version 3.0 u posterior  --  http://www.gnu.org/licenses/gpl-3.0.html
   * LGPL : GNU Lesser General Public License
     version 3.0 u posterior  --  http://www.gnu.org/licenses/lgpl-3.0.html

   Iste diccionario ye feito ta funcionar con programas que faigan servir o 
   corrector Hunspell: LibreOffice, OpenOffice.org 3.2+, Firefox 4+, Thunderbird 5+
   
   A versi�n 0.2 d'o listau de parolas s'ha elaborau emplegando corpus libres como a Wikipedia 
   en aragon�s (http://an.wikipedia.org), y listas de parolas obtenidas d'os diccionarios d'Apertium 
   (http://apertium.svn.sourceforge.net/viewvc/apertium/tags/apertium-es-an/release-2.0/).

   As sucherencias y realimentaci�n sobre o diccionario ortografico son bienplegadas.
   Por favor, escriba as suyas sucherencias y reportes d'errors y/u parolas que faltan 
   ta l'adreza de correu-e an.spellchecker(at)gmail(dot)com 

   Nota: A ortograf�a emplegada ye a proposada por l'Academia de l'Aragon�s - Estudio de Filoloch�a Aragonesa. 
   Puede trobar-se en: http://www.academiadelaragones.org/biblio/EDACAR7_2.pdf
   
   
(en)
Aragonese spelling dictionary.
Version 0.2. (beta)
Copyright (c) 2011 Santiago Paricio (sparicio<at>gmail<dot>com)
Copyright (c) 2011 Juan Pablo Mart�nez (jpmart<at>unizar<dot>es)

   Licences (MPL1.1/GPLv3+/LGPLv3+ Tri-licence):
   * MPL : Mozilla Public License
     version 1.1  --  http://www.mozilla.org/MPL/MPL-1.1.html
   * GPL : GNU General Public License
     version 3.0 or later  --  http://www.gnu.org/licenses/gpl-3.0.html
   * LGPL : GNU Lesser General Public License
     version 3.0 or later  --  http://www.gnu.org/licenses/lgpl-3.0.html

   This dictionary will work with software using the Hunspell spellchecker: 
   as LibreOffice, OpenOffice.org 3.2+, Firefox 4+, Thunderbird 5+
   
   Version 0.2 of the wordlist (an_ES.dic) has been built using free corpuses have been used as Wikipedia 
   in aragonese (http://an.wikipedia.org) and wordlists obtained from Apertium dictionaries
   (http://apertium.svn.sourceforge.net/viewvc/apertium/tags/apertium-es-an/release-2.0/).

   Any suggestions or feedback about the spelling dictionary are welcome.
   Please send your suggestions, error reports and/or missing words to an.spellchecker(at)gmail(dot)com 

   Note: The spelling system for aragon�s can be found at: http://www.academiadelaragones.org/biblio/EDACAR7_2.pdf
   
   
====================================================
   
0.1 (initial release) (5/09/2011)
- 13470 dictionary entries

0.2 (beta) (6/11/2011)
- 20851 dictionary entries (sync with apertium dictionary lemmae).
- repeated entries fixed.
- errors in affix file fixed.
- REP and MAP rules added to improve suggestions considering typical orthography
errors.
