var err = initInstall("Russian spellchecking dictionary", "hunspell-ru@dictionaries.addons.mozilla.org", "1.0.20131101");
if (err != SUCCESS)
    cancelInstall();

var fProgram = getFolder("Program");
err = addDirectory("", "hunspell-ru@dictionaries.addons.mozilla.org",
		   "dictionaries", fProgram, "dictionaries", true);
if (err != SUCCESS)
    cancelInstall();

performInstall();
