

README file for Version 0.2, Dec. 2006
--------------------------------------
These are the dic and affix files needed for
spell checking of Coptic in Bohairic dialect
with hunspell (and OpenOffice.org).

The corpus is still very small, and the dictionary
is rather in an experimental status. Right now, all
words of the Coptic liturgies and the New Testament
are included. Also many Greek words that were adapted
in Bohairic are included, but as rigid words (with no
affix rules).
In future, newer versions should be available at
www.moheb.de
For more detailed information:
http://www.moheb.de/coptic_proofing.html
http://www.moheb.de/coptic_oo.html

Maintainer:
------------
Moheb Mekhaiel, mohebm@gmx.de  OR copt@moheb.de


License policy:
---------------
GNU General Public License applies:
http://www.gnu.org/licenses/gpl.txt