var err = initInstall("Macedonian Dictionary", "mk-mk@dictionaries.addons.mozilla.org", "1.1");
if (err != SUCCESS)
    cancelInstall();

var fProgram = getFolder("Program");
err = addDirectory("", "mk-MK@dictionaries.addons.mozilla.org", "dictionaries", fProgram, "dictionaries", true);
if (err != SUCCESS)
{
	cancelInstall();
}
else
{
	performInstall();
}