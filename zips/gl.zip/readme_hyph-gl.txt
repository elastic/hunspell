Guionizador de galego para OpenOffice.org 3

1. Dereitos de autor
2. Contido
3. Licenza

1. Dereitos de autor
Baseado en Patgen
Creado por Frco. Javier Rial Rodríguez (fjrial@mancomun.org) co asesoramento
lingüístico de Antón Gómez Méixome (meixome@mancomun.org) para Mancomún,
Centro de Referencia e Servizos de Software Libre.

2. Contido

O paquete contén o seguinte:

	readme_hyph-gl.txt	
	hyph_gl.dic,  ficheiro de regras de separación.
	license-gl.txt tradución ao galego da licenza GPLv3
	license-en.txt english version license GPLv3

3. Licenza
Liberado conforme os termos da licenza GNU GPL (version 3)
