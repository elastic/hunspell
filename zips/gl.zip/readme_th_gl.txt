Thesaurus da lingua galega

Os sin�nimos e as formas recomendadas proceden do
Vocabulario ortogr�fico da lingua galega (VOLGa) 
Santamarina Fern�ndez, Ant�n e Gonz�lez Gonz�lez, Manuel (coord.)
Real Academia Galega / Instituto da Lingua Galega, 2004.
http://www.realacademiagalega.org/volga/

Elaboraci�n do thesaurus:
Miguel Solla (bradomin@gmail.com), 2010

Instalaci�n: 
En OpenOffice.org 3 ou superior:
Ferramentas -> Xestor de extensi�ns... -> Engadir...
Despois da instalaci�n, c�mpre fechar todos os documentos abertos 
e volver executar o programa.

Cont�n:
	readme_th_gl.txt (este ficheiro)
	thesaurus_gl.dat
	thesaurus_gl.idx

Licenza: GPLv3. Vexa license.txt ou license-gl.txt

