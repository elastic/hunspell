var err = initInstall("Prawopisny słownik hornjoserbšćiny", "hsb@dictionaries.addons.mozilla.org", "0.0.20060327.3");
if (err != SUCCESS)
    cancelInstall();

var fProgram = getFolder("Program");

err = addDirectory("", "hsb@dictionaries.addons.mozilla.org", "dictionaries", fProgram, "dictionaries", true);
if (err != SUCCESS)
    cancelInstall();

performInstall();
