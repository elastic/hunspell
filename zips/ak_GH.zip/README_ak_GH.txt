Akan SpellChecking Dictionary
Release: 0.1
------------------------------

1. Copyright
2. Installation and Setup
3. Contributing

1. Copyright
============
This package is released under GPL.
Copyright (C) 2006 Ghanathink Foundation

2. Installation and Setup
=========================

Automated
---------
For automatic installation, please follow this URL
http://lingucomponent.openoffice.org/auto_instal.html

If the Akan spellchecker is not available online then
download the offline package from http://kasa.ghanathink.org/

Manual Installation
-------------
For instructions on how to install the Akan dictionary please visit the
following URL
http://lingucomponent.openoffice.org/manual_instal.html

Spellchecker Selection
----------------------
From OpenOffice Writer's main menu, select
Tools -> Options -> Language Settings -> Languages

Under Default language for documents, Select Akan from the language list.


3. Contributing
===============
If you find errors in the spellchecker or would like to contribute new words
to the spellchecker or if you would like to extend the affix file then contact
Paa Kwesi<imbeah@ghanathink.org>

