README.txt (Frysk/English)

[Frysk]
Wurdlisten ferzje 14 novimber 2006 mei oanfollingen yn oanrin nei de nije list yn 2014

***************************************************************************
*****
* Jo wurde freonlik fersocht om dit best�n README-fy.TXT mei te fersprieden    *
* by elke kopy fan dizze Fryske wurdlist (fy.dic en fy.aff).                   *
* It br�ken en fersprieden fan dizze bestannen mei  allinnich �nder de         *
* betingsten fan de yn dit readme-best�n neamde lisinsjes.                     *                                    
     
***************************************************************************
*****

Oer de Fryske wurdlist (fy.dic/fy.aff)
--------------------------------------------------------------------------------

Dizze wurdlist is basearre op de wurdlisten dy't makke  
binne troch de "Fryske Akademy", d�r't ek it oarspronklike copyright leit. 
De Fryske Akademy is eigner fan de wurdlisten en hat dy �nder lisinsje beskikber steld.

[English] 
Wordslist version 14 november 2006 with additions from the new to come list in 2014

***************************************************************************
*****
* You are kindly requested to keep a copy of this file with every copy you     *
* make of the Frisian dictionary (fy.dic and fy.aff).                          *
* Use and/or distribution of these files is only allowed in accordance to the  *
* license conditions as stated in this readme file.                            *
***************************************************************************
*****

About the updated Frisian dictionary (fy.dic/fy.aff)
--------------------------------------------------------------------------------

This dictionary is based on the ispell version of the Frisian wordlist created 
and original copyright by the "Fryske Akademy". 
The Fryske Akademy is owner of these wordlist and has made them available under licence.
