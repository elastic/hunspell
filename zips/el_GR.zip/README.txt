Αυτό το λεξικό  διανέμεται μe την τριπλή αδεια χρήσης  MPL 1.1/GPL 2.0/LGPL 2.1.

***** BEGIN LICENSE BLOCK *****
Version: MPL 1.1/GPL 2.0/LGPL 2.1

The contents of this file are subject to the Mozilla Public License Version 
1.1 (the "License"); you may not use this file except in compliance with 
the License. You may obtain a copy of the License at 
http://www.mozilla.org/MPL/

Software distributed under the License is distributed on an "AS IS" basis,
WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
for the specific language governing rights and limitations under the
License.

The Original Code is http://ispell.source.gr , http://elspell.math.upatras.gr/
The Initial Developer of the Original Code is
Evripidis Papakostas, Steve Stavropulos
Portions created by the Initial Developer are Copyright (C) 2007
the Initial Developer. All Rights Reserved.

Contributor(s):

Alternatively, the contents of this file may be used under the terms of
either the GNU General Public License Version 2 or later (the "GPL"), or
the GNU Lesser General Public License Version 2.1 or later (the "LGPL"),
in which case the provisions of the GPL or the LGPL are applicable instead
of those above. If you wish to allow use of your version of this file only
under the terms of either the GPL or the LGPL, and not to allow others to
use your version of this file under the terms of the MPL, indicate your
decision by deleting the provisions above and replace them with the notice
and other provisions required by the GPL or the LGPL. If you do not delete
the provisions above, a recipient may use your version of this file under
the terms of any one of the MPL, the GPL or the LGPL.

***** END LICENSE BLOCK *****


Ευχαριστίες:
Ευχαριστώ τους (steve):

    * Τον Ευριπίδη Παπακώστα που ξεκίνησε το project και το έφερε σε ένα απίστευτα καλό σημείο. Θερμές ευχαριστίες!
    * Το εργαστήριο ηλεκτρονικών υπολογιστών του Μαθηματικού τμήματος του Πανεπιστημίου της Πάτρας που τώρα πια στεγάζει το project. 

Ευχαριστώ τους (evris (o steve προσυπογράφει)):

    * Σερασκέρη και Μήταλα καθώς και στον κ. Διομήδη Σπινέλη (επίβλεψη της εργασίας τους, αποστολή λέξεων για εμπλουτισμό του λεξιλογίου), που ξεκίνησαν την προσπάθεια του ispell, και που στο δικό τους affix και dictionary βασιστήκαμε.
    * Παναγιώτη Τσακίρη, που εμπλούτισε το λεξικό και μας βοήθησε/ξεσήκωσε στο να πάρουμε μπροστά.
    * Παναγιώτη Λουρίδα που έστειλε λέξεις.
    * Παναγιώτη Βρυώνη (EEEA vrypan) και Βούλα Σανιδά (EEEA voulariba) για την βοήθεια τους στην αλλαγή των affix files κλπ από ispell σε OpenOffice format.
    * Τον Kevin Hendricks (ο υπεύθυνος για τα του MySpell, OpenOffice spellchecker) για την συνεργασία και το χρόνο του.
    * Τον Γιώργο Ευσταθίου για την συνεισφορά του σε νέες λέξεις για το λεξικό.
    * Τον Γιώργο Ζαφόλια (EEEA mpoulis) για το internetικό μάζεμα λιστών λέξεων από sites.
    * Τον xxx (πολλαπλές ευχαριστίες) για τις συνεισφορές του τόσο σε λέξεις, ορθογραφικές διορθώσεις, όσο και στα της αυτόματης παραγωγής κλίσεων επιθέτων και ουσιαστικών για τον εμπλουτισμό των λεξικών και (πάλι και πάλι και πάλι) την voulariba που τα τσέκαρε και τα ενσωμάτωσε.
    * Τον Μιχάλη Καμπριάνη (EEEA mkab) για το ξελάσπωμα στο (άγνωστο για μας) θέμα της perl.
    * Τον Παναγιώτη Πάκο για τα κλιτικά παραδείγματα, τα γκρουπαρίσματα ομοειδών ουσιαστικών, ρημάτων κλπ, για τις οδηγίες του για να φτιάξουμε αυτόματα scripts που να κλίνουν λέξεις, για τα χειροκίνητα ξεσκαρταρίσματά του (μια που τα scripts δεν είναι πάντα τέλεια)
    * Τον steve για το src.rpm του, που λύνει προβλήματα εγκατάστασής του σε συστήματα διαφορετικά από το δικό μου, για τον καθαρισμό του Makefile, του SPEC κλπ. Επίσης ο steve είναι ο άνθρωπος που κρύβεται πίσω από την ιδέα και υλοποίηση του greeklish spellchecker module και της greeklish2gr spellchecking διαδικασίας καθώς και αυτός που έφτιαξε το greek.kbd για τον εντοπισμό των συχνότερων λαθών που οφείλονται σε αναγραμματισμούς.
    * Τέλος την WISE (EEEA papas) που μας έδινε χώρο, ετοίμαζε τις σελίδες, διέθετε το bandwidth κλπ κλπ για να στεγάζεται αυτή εδώ η προσπάθεια. 

