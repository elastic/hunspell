var err = initInstall("Greek Spelling dictionary", "el-GR@dictionaries.addons.mozilla.org", "0.8.5");
if (err != SUCCESS)
    cancelInstall();

var fProgram = getFolder("Program");
err = addDirectory("", "el-GR@dictionaries.addons.mozilla.org",
		   "dictionaries", fProgram, "dictionaries", true);
if (err != SUCCESS)
    cancelInstall();

performInstall();
