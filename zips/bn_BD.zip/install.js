var err = initInstall("Bengali Bangladesh Dictionary", "bn-bd@dictionaries.addons.mozilla.org", "2.0.0.1");
if (err != SUCCESS)
    cancelInstall();

var fProgram = getFolder("Program");
err = addDirectory("", "bn-BD@dictionaries.addons.mozilla.org",
		   "dictionaries", fProgram, "dictionaries", true);
if (err != SUCCESS)
    cancelInstall();

performInstall();
