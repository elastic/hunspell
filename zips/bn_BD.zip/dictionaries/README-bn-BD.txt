Version 0.08
2012-01-04
--
This dictionary is based on a subset of the original
Bengali wordlist created by Dr. Abhijit Das and
Taneem Ahmed for Aspell and thus is covered by
their original GPL license.

Updated By:
  Jamil Ahmed <itsjamil at gmail com>, <jamil at ankur org bd>
  Md. Rezwan Shahid <rezwan at ankur org bd>
  Loba Yeasmeen <loba at ankur org bd>
  Israt Jahan <israt at ankur org bd>
  Sadia Afroz <sadia at ankur org bd>
  Sazzad Chowdhury <sazzad at ankur org bd>
  Robin Mehdee <robin at ankur org bd>	

Copyright Terms: GPLv2 (see the file Copyright for the exact terms)
Wordlist URL: http://www.ankur.org.bd/wiki/Download
