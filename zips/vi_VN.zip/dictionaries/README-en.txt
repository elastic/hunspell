The vi_VN.aff rules were improved by Ivan Garcia - capiscuas@gmail.com (Sept 2007)
More Info about how to install the package in Openoffice and Firefox here: 
http://code.google.com/p/hunspell-spellcheck-vi/

ORIGINAL README:
-----------------------------
See original package:  http://ftp.gnu.org/gnu/aspell/dict/vi/aspell6-vi-0.01.1-1.tar.bz2 
Conversion made by Laszlo Nemeth, for demonstration of Hunspell Unicode support
(see http://hunspell.sourceforge.net)


GNU Aspell 0.60 Vietnamese (Việt ngữ) Dictionary Package
Version 0.01.1-1
2004-08-24
Original Word List By:
 Hồ Ngọc Đức <duc at informatik uni-leipzig de>
Copyright Terms: GPLv2 (see the file Copyright for the exact terms)
