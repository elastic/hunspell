var err = initInstall("Telugu", "indlinux-telugu@lists.sourceforge.net", "0.2");
if (err != SUCCESS)
    cancelInstall();

var fProgram = getFolder("Program");
err = addDirectory("", "indlinux-telugu@lists.sourceforge.net",
		   "dictionaries", fProgram, "dictionaries", true);
if (err != SUCCESS)
    cancelInstall();

performInstall();
