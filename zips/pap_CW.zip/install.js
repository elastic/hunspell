const APP_NAME			= "Dikshonario di Papiamentu/Antia hulandes";
const APP_PACKAGE		= "pap-an@lasindias.org";
const APP_VERSION		= "0.5";

var err = initInstall(APP_NAME, APP_PACKAGE, APP_VERSION);
if (err != SUCCESS)
    cancelInstall();

var fProgram = getFolder("Program");
err = addDirectory("", "pap-an@lasindias.org",
		   "dictionaries", fProgram, "dictionaries", true);
if (err != SUCCESS)
    cancelInstall();

performInstall();
