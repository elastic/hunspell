{\rtf1\ansi\ansicpg1252\cocoartf1138\cocoasubrtf470
{\fonttbl\f0\fnil\fcharset222 Ayuthaya;}
{\colortbl;\red255\green255\blue255;}
\paperw11900\paperh16840\margl1440\margr1440\vieww10800\viewh8400\viewkind0
\deftab720
\pard\pardeftab720\ri380\qj

\f0\fs24 \cf0 READ ME 							\
									\
\
Rescue Language improves the database on a regular basis and some of these improvements are: introduction, elimination and correction of words, as well as support to other applications.\'a0\
}