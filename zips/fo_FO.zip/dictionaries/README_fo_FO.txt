�ki Nielsen - a-nielsen � post punktum olivant punktum fo
Almanna- og heilsum�lar��i�
Arnv�r M. � Torkilsheyggi - arnvor � torkilsheyggi punktum fo
Arthur Olsen - arthur � flug punktum fo
D�nial Olsen - danial � com-data punktum fo
D�vur - davur � dsmedia punktum fo
D=E1nial Olsen - danial � com-data punktum fo
Eiler Hansen - eiler � elektron punktum fo
Eitt forrit hj� Jacob Sparre Andersen - sparre � nbi punktum dk
Hans Jacob Thomsen
H=F8gni Weihe - weihe � kiku punktum dk
Jacob Sparre An�
Jacob Sparre Andersen - munin-sparre � jacob-sparre punktum dk
Jacob Sparre Andersen - sparre � crs4 punktum it
Jacob Sparre Andersen - sparre � jacob-sparre punktum dk
Jacob Sparre Andersen - sparre � nbi punktum dk
J�n Johannesen - wolfmoon � post punktum olivant punktum fo
Karsten
Kim Isdal Knudsen - kim � isdal punktum dk
�livant - http://www punktum olivant punktum fo/
Pincio
Rói á Torkilsheyggi - roi � torkilsheyggi punktum fo
RAF
R�i � Torkilsheyggi - roi � torkilsheyggi punktum fo
Svend Heinesen - she � formula punktum fo
torkil
Torkil Zachariassen - torkil � flug punktum fo
Torkil Zachariassen - torkil � flug punktum fo
unknown
�tvarp F�roya
�tvarp F�roya - http://www punktum uf punktum fo/
		    GNU GENERAL PUBLIC LICENSE
		       Version 2, June 1991

 Copyright (C) 1989, 1991 Free Software Foundation, Inc.
                       59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 Everyone is permitted to copy and distribute verbatim copies
 of this license document, but changing it is not allowed.


