This Macedonian dictionary was created by:
Taras Bendik

The Macedonian dictionary is covered by the GNU GPL License and 
supports Macedonian language (mk_MK)

Project was realized by Free/Libre Software Organisation of Macedonia (OSSM).

Bug report: <vladoboss@mt.net.mk

======================
INSTALLATION
======================

1. Отпакувајте ја zip датотеката во direktorium_kade_e_openoffice/share/dict/ooo/

2. Внатре се наоѓа и датотека dictionary.lst променете ја и допишете на крајот DICT mk MK mk_MK

3. Отворете го Опенофис и одете во Алатки->Опции->Поставувања за јазик->Помош за пишување->Уреди и изберете македонски.

4. Рестартирајте го Опенофис.
