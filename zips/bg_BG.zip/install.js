var err = initInstall("Bulgarian Dictionary", "bg-BG@dictionaries.addons.mozilla.org", "4.3");
if (err != SUCCESS)
    cancelInstall();

var fProgram = getFolder("Program");
err = addDirectory("", "bg-BG@dictionaries.addons.mozilla.org",
			"dictionaries", fProgram, "dictionaries", true);
if (err != SUCCESS)
    cancelInstall();

performInstall();
