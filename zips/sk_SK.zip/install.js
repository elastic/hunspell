var err = initInstall("Slovníky slovenského pravopisu (bez aj s diakritikou)", "sk@dictionaries.addons.mozilla.org", "2.04.0");
if (err != SUCCESS)
    cancelInstall();

var fProgram = getFolder("Program");
err = addDirectory("", "sk@dictionaries.addons.mozilla.org",
		   "dictionaries", fProgram, "dictionaries", true);
if (err != SUCCESS)
    cancelInstall();

performInstall();
