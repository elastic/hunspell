var err = initInstall("Fjalori drejtshkrimor i gjuh�s shqipe", "sq@dictionaries.addons.mozilla.org", "1.6.9");
if (err != SUCCESS)
    cancelInstall();

var fProgram = getFolder("Program");
err = addDirectory("", "sq@dictionaries.addons.mozilla.org",
		   "dictionaries", fProgram, "dictionaries", true);
if (err != SUCCESS)
    cancelInstall();

performInstall();