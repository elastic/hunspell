
 Copyright

 Malay Spellchecker v0.1 - 07/10/04
-----------------------------------------
This is an initial version, please check:
http://lingucomponent.openoffice.org/download_dictionary.html
OR
http://opensource.mimos.my
for a latest version.

The affix file has been created completely from scratch
by MIMOS Open Source Group:
 1) Shahril Saad
 2) Ismas Suraya
 3) Rudhuwan Abu Bakar
 4) Syed Ahmad Shazali 

 Acknowledgements
------------------
We would like to offer our gratitude to: 
 1) Profesor Abdullah Hassan - Universiti Perguruan Sultan Idris (UPSI)
 2) Puan Ainon Mohd.- PTS Publications Sdn Bhd.
for their contribution in Malay root words.

 License
---------
This dictionary is covered by the 'GNU Free Documentation License',
viewable at http://www.gnu.org/copyleft/fdl.html 

 Contact
---------
MIMOS Open Source Group welcomes any suggestions or comments.
E-mail : osslocalize@mimos.my

 Changelog
-----------
30/12/2004 - 2nd release, add more root words.
07/10/2004 - 1st release



