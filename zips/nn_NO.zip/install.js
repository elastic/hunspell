var err = initInstall("Norsk nynorsk ordliste", "nn-NO@dictionaries.addons.mozilla.org", "2.1.0");
if (err != SUCCESS)
    cancelInstall();

var fProgram = getFolder("Program");
err = addDirectory("", "nn-NO@dictionaries.addons.mozilla.org",
		   "dictionaries", fProgram, "dictionaries", true);
if (err != SUCCESS)
    cancelInstall();

performInstall();
