var err = initInstall("Sanskrit Spell Checker", "sa-IN@dellalibera.sf.net", "2.1");
if (err != SUCCESS)
    cancelInstall();

var fProgram = getFolder("Program");
err = addDirectory("", "sa-IN@dellalibera.sf.net",
		   "dictionaries", fProgram, "dictionaries", true);
if (err != SUCCESS)
    cancelInstall();

performInstall();
