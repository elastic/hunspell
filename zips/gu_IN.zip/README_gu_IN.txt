Gujarati Dictionary for OpenOffice.org

Maintained By:
Kartik Mistry <kartik dot mistry at gmail dot com>

Original Word List By:
Utkarsh Project volunteers <support at utkarsh dot org>

Copyright Terms: GPL

Wordlist URL: http://www.utkarsh.org/dictionary/
