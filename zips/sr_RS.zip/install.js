var err = initInstall("Serbian Dictionary", "sr-RS@dictionaries.addons.mozilla.org", "2.0.0.2");
if (err != SUCCESS)
    cancelInstall();

var fProgram = getFolder("Program");
err = addDirectory("", "sr-RS@dictionaries.addons.mozilla.org",
		   "dictionaries", fProgram, "dictionaries", true);
if (err != SUCCESS)
    cancelInstall();

performInstall();