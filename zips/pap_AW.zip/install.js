const APP_NAME			= "Diccionario di Papiamento/Aruba";
const APP_PACKAGE		= "manuel@elarte.coop";
const APP_VERSION		= "0.2";

var err = initInstall(APP_NAME, APP_PACKAGE, APP_VERSION);
if (err != SUCCESS)
    cancelInstall();

var fProgram = getFolder("Program");
err = addDirectory("", "manuel@elarte.coop",
		   "dictionaries", fProgram, "dictionaries", true);
if (err != SUCCESS)
    cancelInstall();

performInstall();
