var err = initInstall("Punjabi", "pa_IN@dellalibera.sf.net", "2.1");
if (err != SUCCESS)
    cancelInstall();

var fProgram = getFolder("Program");
err = addDirectory("", "pa_IN@dellalibera.sf.net",
		   "dictionaries", fProgram, "dictionaries", true);
if (err != SUCCESS)
    cancelInstall();

performInstall();
