var err = initInstall("Nepali SpellChecking dictionary\n(based on dictionary compiled by Madan Puraskar Pustakalaya)", "ne-NP@dictionaries.addons.mozilla.org", "1.1");
if (err != SUCCESS)
    cancelInstall();

var fProgram = getFolder("Program");
err = addDirectory("", "ne-NP@dictionaries.addons.mozilla.org",
		   "dictionaries", fProgram, "dictionaries", true);
if (err != SUCCESS)
    cancelInstall();

performInstall();