DICTIONNAIRE ORTHOGRAPHIQUE BRETON

Auteur : An Drouizig (http://www.drouizig.org/)

Licences :
- Mozilla Public License, version 1.1 ou plus récente (MPL)
	http://www.mozilla.org/MPL/MPL-1.1.html

- GNU General Public License, version 2 ou plus récente (GPL)
	http://www.gnu.org/licenses/gpl-2.0.html

- GNU Lesser General Public License, version 2.1 ou plus récente (LGPL)
	http://www.gnu.org/licenses/lgpl-2.1.html

