﻿The Slovenian thesaurus is developed as a part of project/
Slovenski tezaver nastaja v okviru projekta:
   OdprtiTezaver (www.tezaver.si)
This dictionary pack includes version/Paket vsebuje različico:
   1.6.16500
Thesaurus managed and edited by/Tezaver pripravlja in ureja:
   Martin Srebotnjak (miles at filmsi net)
Thesaurus data licensed under both/Podatki tezavra so izdani pod licencama:
   CC-GNU GPL in/and CC-GNU LGPL.

The LibreOffice/OpenOffice.org extension by/Razširitev LibreOffice/OpenOffice.org pripravil:
   Martin Srebotnjak, <miles@filmsi.net>

Bug report/O napakah poročajte:
   <info@tezaver.si>

=======================================================================
http://external.openoffice.org/ form data:

Product Name: Slovenian thesaurus
Product Version: 1.6.16500
Vendor or Owner Name: Martin Srebotnjak
Vendor or Owner Contact: miles@filmsi.net
OpenOffice.org Contact: filmsi@openoffice.org
Date of First Use / date of License: NA / September 2006, January 2012 (double license)
URL for Product Information: http://www.tezaver.si
URL for License: http://www.gnu.org/licenses/gpl-3.0.html & http://www.gnu.org/licenses/lgpl-2.1.html
Purpose: Slovenian thesaurus
Type of Encryption: none
Binary or Source Code: Source
=======================================================================

For the avoidance of doubt, except that if any license choice other
than GPL or LGPL is available it will apply instead, Sun elects to use
only the Lesser General Public License version 2.1 (LGPLv2) at this
time for any software where a choice of LGPL license versions is made
available with the language indicating that LGPLv2.1 or any later
version may be used, or where a choice of which version of the LGPL is
applied is otherwise unspecified.
