var err = initInstall("Geiriadur Cymraeg", "cy-GB-1@dictionaries.addons.mozilla.org", "1.08");
if (err != SUCCESS)
    cancelInstall();

var fProgram = getFolder("Program");
err = addDirectory("", "cy-GB-1@dictionaries.addons.mozilla.org",
		   "dictionaries", fProgram, "dictionaries", true);
if (err != SUCCESS)
    cancelInstall();

performInstall();
